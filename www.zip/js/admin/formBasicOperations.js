function deletePic(id, folder, url, block) {
    if (!confirm("Уверены, что хотите удалить картинку?")) {
        return true;
    }
    $.ajax({
        type: "POST",
        url: url,
        data: "id=" + id +"&folder=" + folder,                
        success: function(data){
            var obj = $.parseJSON(data);
            if (obj.error == 0) {
                    $("#"+block).html('<div class="'+block+'">картинка удалена</div>');
            } else {
                if (obj.message != '') {
                    alert (obj.message);
                } else {
                    alert ('упс..... ошибочка');
                }
            }
        }
    });
    return false;
}