function countryDelete(id) {
    if (!confirm("Уверены, что хотите удалить страну, ее переводы, города относящиеся к ней и их переводы?")) {
        return true;
    }
    $.ajax({
        type: "POST",
        url: "/admin/geography/countryDelete",
        data: "id=" + id,                
        success: function(data){
            var obj = $.parseJSON(data);
            if (obj.error == 0) {
                $("#tr-"+id).html('<td colspan="6" class="u-delete">страна, ее переводы, города относящиеся к ней и их переводы удалены</td>');
                $("#tr-"+id).hide(3500);
            } else {
                if (obj.message != '') {
                    alert (obj.message);
                } else {
                    alert ('упс..... ошибочка');
                }
            }
        }
    });
    return false;
}