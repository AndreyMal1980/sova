function cityDelete(id) {
    if (!confirm("Уверены, что хотите удалить город и его переводы?")) {
        return true;
    }
    $.ajax({
        type: "POST",
        url: "/admin/geography/cityDelete",
        data: "id=" + id,                
        success: function(data){
            var obj = $.parseJSON(data);
            if (obj.error == 0) {
                $("#tr-"+id).html('<td colspan="6" class="u-delete">город и его переводы удалены</td>');
                $("#tr-"+id).hide(3500);
            } else {
                if (obj.message != '') {
                    alert (obj.message);
                } else {
                    alert ('упс..... ошибочка');
                }
            }
        }
    });
    return false;
}