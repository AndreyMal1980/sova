function calendarDelete(id, type) {
    if (!confirm("Уверены, что хотите удалить событие?")) {
        return true;
    }
    $.ajax({
        type: "POST",
        url: "/admin/calendar/delete",
        data: "id=" + id,                
        success: function(data){
            var obj = $.parseJSON(data);
            
            if (obj.error == 0 && type == 1) {
                $("#tr-"+id).html('<td colspan="7" class="u-delete">событие удалено</td>');
                $("#tr-"+id).hide(3500);
            }else if (obj.error == 0 && type==0) {
                //$("#tr-"+id).html('<td colspan="7" class="u-delete">событие удалено</td>');
                //$("#tr-"+id).hide(3500);
            } 
            else {
                if (obj.message != '') {
                    alert (obj.message);
                } else {
                    alert ('упс..... ошибочка');
                }
            }
        }
    });
    return false;
}
