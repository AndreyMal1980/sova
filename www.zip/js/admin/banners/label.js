function deleteByLabel(label, i) {
    if (!confirm("Уверены, что хотите удалить баннеры с меткой '"+label+"'?")) {
        return true;
    }
    $.ajax({
        type: "POST",
        url: "/admin/banners/deleteByLabel",
        data: "label=" + label,
        success: function(data){
            var obj = $.parseJSON(data);
            if (obj.error == 0) {
                $("#tr-"+i).html('<td colspan="6" class="u-delete">баннеры удалены</td>');
                $("#tr-"+i).hide(3500);
            } else {
                if (obj.message != '') {
                    alert (obj.message);
                } else {
                    alert ('упс..... ошибочка');
                }
            }
        }
    });
    return false;
}