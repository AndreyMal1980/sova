function CMSNewsDelete(id) {
    if (!confirm("Уверены, что хотите удалить новость cms?")) {
        return true;
    }
    $.ajax({
        type: "POST",
        url: "/admin/CMSNews/delete",
        data: "id=" + id,                
        success: function(data){
            var obj = $.parseJSON(data);
            if (obj.error == 0) {
                $("#tr-"+id).html('<td colspan="5" class="u-delete">новость удалена</td>');
                $("#tr-"+id).hide(3500);
            } else {
                if (obj.message != '') {
                    alert (obj.message);
                } else {
                    alert ('упс..... ошибочка');
                }
            }
        }
    });
    return false;
}
